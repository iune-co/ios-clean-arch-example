import XCTest
@testable import domain_recipe

final class domain_recipeTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(domain_recipe().text, "Hello, World!")
    }
}
