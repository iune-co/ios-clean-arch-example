public protocol Resolver {
    func resolve<T>() -> T
}
