public enum HTTPHeaderName: String {
    case contentType = "Content-Type"
    case authorization = "Authorization"
}
