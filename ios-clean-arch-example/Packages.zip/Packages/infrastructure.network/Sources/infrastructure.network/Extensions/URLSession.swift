import Foundation

extension URLSession: NetworkSession {}
