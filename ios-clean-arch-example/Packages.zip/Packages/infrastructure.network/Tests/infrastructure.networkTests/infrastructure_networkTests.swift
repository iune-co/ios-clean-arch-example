import XCTest
@testable import infrastructure_network

final class infrastructure_networkTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(infrastructure_network().text, "Hello, World!")
    }
}
