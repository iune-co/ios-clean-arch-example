import XCTest
@testable import data_recipe

final class data_recipeTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(data_recipe().text, "Hello, World!")
    }
}
